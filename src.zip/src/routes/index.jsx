import { useState, useMemo } from "react";
import { useLocation } from 'react-router-dom';
import { useRoutes, Navigate } from 'react-router-dom';

import LoginPage from '@/routes/Login';
import DashboardPage from '@/routes/Dashboard';
import ClientsPage from '@/routes/Clients';
import AddClientPage from '@/routes/Clients/AddClient';
import LeadsPage from '@/routes/Leads';
import AddLeadPage from '@/routes/Leads/AddLead';
import BranchesPage from '@/routes/Branches';
import AddBranchPage from '@/routes/Branches/AddBranch';
import RoleManagementPage from '@/routes/RoleManagement';
import AddRolePage from '@/routes/RoleManagement/AddRole';

import Header from '@/components/Header';
import Sidebar from '@/components/Sidebar';
import UserWidget from '@/features/user/components/UserWidget';
import ProtectedRoute from '@/components/ProtectedRoute';

import { getUserRole } from '@/utils/authUtils';
import { ROUTES, getAllowedRoutes } from '@/config/roleConfig';

export function AppRoutes() {
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(false);
  
  // Get user role and allowed routes
  const userRole = getUserRole();
  const allowedRoutes = useMemo(() => getAllowedRoutes(userRole), [userRole]);

  // Define all routes with protection
  const allRoutes = [
    {
      path: '/',
      element: <LoginPage />,
    },
    {
      path: '/dashboard',
      element: (
        <ProtectedRoute requiredRoute={ROUTES.DASHBOARD}>
          <DashboardPage />
        </ProtectedRoute>
      ),
    },
    {
      path: '/agent',
      element: (
        <ProtectedRoute requiredRoute={ROUTES.AGENT}>
          <ClientsPage />
        </ProtectedRoute>
      ),
    },
    {
      path: '/agent/add',
      element: (
        <ProtectedRoute requiredRoute={ROUTES.AGENT_ADD}>
          <AddClientPage />
        </ProtectedRoute>
      ),
    },
    {
      path: '/leads',
      element: (
        <ProtectedRoute requiredRoute={ROUTES.LEADS}>
          <LeadsPage />
        </ProtectedRoute>
      ),
    },
    {
      path: '/lead/add',
      element: (
        <ProtectedRoute requiredRoute={ROUTES.LEAD_ADD}>
          <AddLeadPage />
        </ProtectedRoute>
      ),
    },
    {
      path: '/branches',
      element: (
        <ProtectedRoute requiredRoute={ROUTES.BRANCHES}>
          <BranchesPage />
        </ProtectedRoute>
      ),
    },
    {
      path: '/branch/add',
      element: (
        <ProtectedRoute requiredRoute={ROUTES.BRANCH_ADD}>
          <AddBranchPage />
        </ProtectedRoute>
      ),
    },
    {
      path: '/role-management',
      element: (
        <ProtectedRoute requiredRoute={ROUTES.ROLE_MANAGEMENT}>
          <RoleManagementPage />
        </ProtectedRoute>
      ),
    },
    {
      path: '/role-management/add',
      element: (
        <ProtectedRoute requiredRoute={ROUTES.ROLE_MANAGEMENT_ADD}>
          <AddRolePage />
        </ProtectedRoute>
      ),
    },
    // Catch-all route for undefined paths
    {
      path: '*',
      element: <Navigate to="/dashboard" replace />,
    },
  ];

  const element = useRoutes(allRoutes);

  // hide Header & Sidebar on login route
  const isLoginPage = location.pathname === '/';

  return (
    <div className="min-h-screen flex bg-[#BBA473]">
      {!isLoginPage && (
        <Sidebar 
          isOpen={isOpen} 
          setIsOpen={setIsOpen} 
          isCollapsed={isCollapsed} 
          setIsCollapsed={setIsCollapsed}
          userRole={userRole}
        />
      )}

      {/* Main Content Wrapper */}
      <div 
        className={`
          flex flex-col flex-1 min-w-0
          transition-all duration-300 ease-in-out
          ${!isLoginPage 
            ? isCollapsed 
              ? 'lg:ml-20' 
              : 'lg:ml-64' 
            : ''
          }
        `}
      >
        {!isLoginPage && (
          <Header
            rightWidget={<UserWidget />}
            menuItems={[
              { label: 'Home', href: '/dashboard', testId: 'home-link' },
              { label: 'Clients', href: '/agent', testId: 'clients-link' },
            ]}
          />
        )}

        {/* Main Content Area - Full Width */}
        <main 
          className={`
            flex-1 w-full
            overflow-x-hidden
            ${!isLoginPage ? 'bg-gray-50' : 'bg-white'}
          `}
        >
          {element}
        </main>
      </div>
    </div>
  );
}