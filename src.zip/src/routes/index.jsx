import { useState, useMemo, Suspense, lazy } from "react";
import { useLocation } from 'react-router-dom';
import { useRoutes, Navigate } from 'react-router-dom';

import Header from '@/components/Header';
import Sidebar from '@/components/Sidebar';
import UserWidget from '@/features/user/components/UserWidget';
import ProtectedRoute from '@/components/ProtectedRoute';
import { RouteLoadingFallback } from '@/components/LoadingSpinner';

import { getUserRole } from '@/utils/authUtils';
import { ROUTES, getAllowedRoutes } from '@/config/roleConfig';

// ⭐ Lazy load route components for better performance
const LoginPage = lazy(() => import('@/routes/Login'));
const DashboardPage = lazy(() => import('@/routes/Dashboard'));
const ClientsPage = lazy(() => import('@/routes/Clients'));
const AddClientPage = lazy(() => import('@/routes/Clients/AddClient'));
const LeadsPage = lazy(() => import('@/routes/Leads'));
const AddLeadPage = lazy(() => import('@/routes/Leads/AddLead'));
const BranchesPage = lazy(() => import('@/routes/Branches'));
const AddBranchPage = lazy(() => import('@/routes/Branches/AddBranch'));
const RoleManagementPage = lazy(() => import('@/routes/RoleManagement'));
const AddRolePage = lazy(() => import('@/routes/RoleManagement/AddRole'));

export function AppRoutes() {
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(false);
  
  // Get user role and allowed routes
  const userRole = getUserRole();
  const allowedRoutes = useMemo(() => getAllowedRoutes(userRole), [userRole]);

  // Define all routes with protection and Suspense
  const allRoutes = [
    {
      path: '/',
      element: (
        <Suspense fallback={<RouteLoadingFallback />}>
          <LoginPage />
        </Suspense>
      ),
    },
    {
      path: '/dashboard',
      element: (
        <Suspense fallback={<RouteLoadingFallback />}>
          <ProtectedRoute requiredRoute={ROUTES.DASHBOARD}>
            <DashboardPage />
          </ProtectedRoute>
        </Suspense>
      ),
    },
    {
      path: '/agent',
      element: (
        <Suspense fallback={<RouteLoadingFallback />}>
          <ProtectedRoute requiredRoute={ROUTES.AGENT}>
            <ClientsPage />
          </ProtectedRoute>
        </Suspense>
      ),
    },
    {
      path: '/agent/add',
      element: (
        <Suspense fallback={<RouteLoadingFallback />}>
          <ProtectedRoute requiredRoute={ROUTES.AGENT_ADD}>
            <AddClientPage />
          </ProtectedRoute>
        </Suspense>
      ),
    },
    {
      path: '/leads',
      element: (
        <Suspense fallback={<RouteLoadingFallback />}>
          <ProtectedRoute requiredRoute={ROUTES.LEADS}>
            <LeadsPage />
          </ProtectedRoute>
        </Suspense>
      ),
    },
    {
      path: '/lead/add',
      element: (
        <Suspense fallback={<RouteLoadingFallback />}>
          <ProtectedRoute requiredRoute={ROUTES.LEAD_ADD}>
            <AddLeadPage />
          </ProtectedRoute>
        </Suspense>
      ),
    },
    {
      path: '/branches',
      element: (
        <Suspense fallback={<RouteLoadingFallback />}>
          <ProtectedRoute requiredRoute={ROUTES.BRANCHES}>
            <BranchesPage />
          </ProtectedRoute>
        </Suspense>
      ),
    },
    {
      path: '/branch/add',
      element: (
        <Suspense fallback={<RouteLoadingFallback />}>
          <ProtectedRoute requiredRoute={ROUTES.BRANCH_ADD}>
            <AddBranchPage />
          </ProtectedRoute>
        </Suspense>
      ),
    },
    {
      path: '/role-management',
      element: (
        <Suspense fallback={<RouteLoadingFallback />}>
          <ProtectedRoute requiredRoute={ROUTES.ROLE_MANAGEMENT}>
            <RoleManagementPage />
          </ProtectedRoute>
        </Suspense>
      ),
    },
    {
      path: '/role-management/add',
      element: (
        <Suspense fallback={<RouteLoadingFallback />}>
          <ProtectedRoute requiredRoute={ROUTES.ROLE_MANAGEMENT_ADD}>
            <AddRolePage />
          </ProtectedRoute>
        </Suspense>
      ),
    },
    // Catch-all route for undefined paths
    {
      path: '*',
      element: <Navigate to="/dashboard" replace />,
    },
  ];

  const element = useRoutes(allRoutes);

  // hide Header & Sidebar on login route
  const isLoginPage = location.pathname === '/';

  return (
    <div className="min-h-screen flex bg-[#BBA473]">
      {!isLoginPage && (
        <Sidebar 
          isOpen={isOpen} 
          setIsOpen={setIsOpen} 
          isCollapsed={isCollapsed} 
          setIsCollapsed={setIsCollapsed}
          userRole={userRole}
        />
      )}

      {/* Main Content Wrapper with smooth transitions */}
      <div 
        className={`
          flex flex-col flex-1 min-w-0
          transition-all duration-300 ease-in-out
          ${!isLoginPage 
            ? isCollapsed 
              ? 'lg:ml-20' 
              : 'lg:ml-64' 
            : ''
          }
        `}
      >
        {!isLoginPage && (
          <Header
            rightWidget={<UserWidget />}
            menuItems={[
              { label: 'Home', href: '/dashboard', testId: 'home-link' },
              { label: 'Clients', href: '/agent', testId: 'clients-link' },
            ]}
          />
        )}

        {/* Main Content Area with fade-in animation */}
        <main 
          className={`
            flex-1 w-full
            overflow-x-hidden
            ${!isLoginPage ? 'bg-gray-50' : 'bg-white'}
            animate-fadeIn
          `}
        >
          {element}
        </main>
      </div>
    </div>
  );
}